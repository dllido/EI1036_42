<?php
/*
Author URI: lola
Author Email: dllido@uji.es
Version: 1.0
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html
*/

include('include/functions.php');
my_datos(); 
?>